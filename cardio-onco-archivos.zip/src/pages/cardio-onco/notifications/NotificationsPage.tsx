/**
 * NotificationsPage — vista del paciente: notificaciones del programa
 *
 * Ruta sugerida: /cardio-onco/notifications  (rol paciente)
 *
 * Lista las notificaciones (recursos Communication) dirigidas al paciente
 * autenticado, agrupadas por estado (pendientes / atendidas / vencidas).
 */

import { useEffect, useMemo, useState } from 'react';
import { useMedplum, useMedplumProfile } from '@medplum/react';
import {
  BellAlertIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  InboxIcon,
} from '@heroicons/react/24/outline';
import type { Communication } from '@medplum/fhirtypes';

type NotifStatus = 'pending' | 'completed' | 'overdue';

interface UINotif {
  id: string;
  subject: string;
  body: string;
  sent: string;
  status: NotifStatus;
  raw: Communication;
}

export default function NotificationsPage(): JSX.Element {
  const medplum = useMedplum();
  const profile = useMedplumProfile();
  const [items, setItems] = useState<UINotif[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (!profile) return;
    const load = async () => {
      setLoading(true);
      const bundle = await medplum.searchResources('Communication', {
        recipient: `Patient/${profile.id}`,
        _sort: '-sent',
        _count: 50,
      });
      const now = Date.now();
      setItems(
        bundle.map((c) => ({
          id: c.id ?? '',
          subject: c.topic?.text ?? c.payload?.[0]?.contentString?.slice(0, 60) ?? 'Recordatorio',
          body: c.payload?.[0]?.contentString ?? '',
          sent: c.sent ?? '',
          status: deriveStatus(c, now),
          raw: c,
        })),
      );
      setLoading(false);
    };
    void load();
  }, [medplum, profile]);

  const grouped = useMemo(() => {
    return {
      pending: items.filter((x) => x.status === 'pending'),
      overdue: items.filter((x) => x.status === 'overdue'),
      completed: items.filter((x) => x.status === 'completed'),
    };
  }, [items]);

  const markCompleted = async (notif: UINotif) => {
    await medplum.updateResource({
      ...notif.raw,
      status: 'completed',
      received: new Date().toISOString(),
    });
    setItems((prev) =>
      prev.map((x) => (x.id === notif.id ? { ...x, status: 'completed' } : x)),
    );
  };

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <header className="mb-8 border-b border-slate-200 pb-6">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-rose-700">
          <BellAlertIcon className="h-4 w-4" />
          Programa Cardio-Oncológico — Tus notificaciones
        </div>
        <h1 className="mt-3 font-serif text-3xl text-slate-900">Tu agenda de seguimiento</h1>
        <p className="mt-2 max-w-xl text-sm text-slate-600">
          Estos son los recordatorios y actividades que tu equipo de cardio-oncología programó
          para vos. Tocá una notificación para ver el detalle o marcarla como atendida.
        </p>
      </header>

      {loading && <p className="text-sm text-slate-500">Cargando…</p>}

      {!loading && items.length === 0 && (
        <EmptyState
          icon={<InboxIcon className="h-12 w-12 text-slate-400" />}
          title="No tenés notificaciones pendientes"
          subtitle="Cuando tu equipo médico active el plan de seguimiento, las verás acá."
        />
      )}

      {grouped.overdue.length > 0 && (
        <Section
          title="Pendientes vencidas"
          subtitle="Estas actividades superaron la fecha programada. Comunicate con el equipo médico."
          tone="overdue"
        >
          {grouped.overdue.map((n) => (
            <NotifCard key={n.id} notif={n} onComplete={() => markCompleted(n)} />
          ))}
        </Section>
      )}

      {grouped.pending.length > 0 && (
        <Section title="Próximas" subtitle="Actividades programadas que aún no realizaste." tone="pending">
          {grouped.pending.map((n) => (
            <NotifCard key={n.id} notif={n} onComplete={() => markCompleted(n)} />
          ))}
        </Section>
      )}

      {grouped.completed.length > 0 && (
        <Section title="Atendidas" subtitle="Historial de las que ya marcaste." tone="completed">
          {grouped.completed.map((n) => (
            <NotifCard key={n.id} notif={n} onComplete={() => markCompleted(n)} />
          ))}
        </Section>
      )}
    </div>
  );
}

function deriveStatus(c: Communication, now: number): NotifStatus {
  if (c.status === 'completed') return 'completed';
  const sent = c.sent ? new Date(c.sent).getTime() : NaN;
  // Si pasaron > 48 h desde el envío y no se marcó como recibida → vencida.
  if (Number.isFinite(sent) && now - sent > 48 * 60 * 60 * 1000) return 'overdue';
  return 'pending';
}

/* ============ Sub-components ============ */

function Section({
  title,
  subtitle,
  tone,
  children,
}: {
  title: string;
  subtitle: string;
  tone: 'pending' | 'overdue' | 'completed';
  children: React.ReactNode;
}) {
  const palette = {
    pending: 'border-amber-300 bg-amber-50',
    overdue: 'border-rose-300 bg-rose-50',
    completed: 'border-emerald-300 bg-emerald-50',
  }[tone];
  return (
    <section className={`mb-8 rounded-lg border ${palette} p-5`}>
      <header className="mb-4 flex items-baseline justify-between">
        <h2 className="font-serif text-xl text-slate-900">{title}</h2>
        <p className="text-xs italic text-slate-600">{subtitle}</p>
      </header>
      <div className="space-y-3">{children}</div>
    </section>
  );
}

function NotifCard({ notif, onComplete }: { notif: UINotif; onComplete: () => void }) {
  const Icon =
    notif.status === 'completed'
      ? CheckCircleIcon
      : notif.status === 'overdue'
        ? ExclamationTriangleIcon
        : BellAlertIcon;
  return (
    <article className="flex items-start gap-3 rounded border border-slate-200 bg-white p-4 shadow-sm">
      <Icon
        className={`h-5 w-5 flex-shrink-0 ${
          notif.status === 'completed'
            ? 'text-emerald-700'
            : notif.status === 'overdue'
              ? 'text-rose-700'
              : 'text-amber-700'
        }`}
      />
      <div className="flex-1">
        <h3 className="font-serif text-base text-slate-900">{notif.subject}</h3>
        <p className="mt-1 text-sm text-slate-700">{notif.body}</p>
        <p className="mt-2 font-mono text-[11px] uppercase tracking-wider text-slate-500">
          {notif.sent ? new Date(notif.sent).toLocaleDateString('es-AR', {
            day: '2-digit', month: 'short', year: 'numeric',
          }) : '—'}
        </p>
      </div>
      {notif.status !== 'completed' && (
        <button
          type="button"
          onClick={onComplete}
          className="rounded bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-slate-700"
        >
          Marcar atendida
        </button>
      )}
    </article>
  );
}

function EmptyState({ icon, title, subtitle }: { icon: JSX.Element; title: string; subtitle: string }) {
  return (
    <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
      <div className="mx-auto mb-4 inline-block">{icon}</div>
      <h2 className="font-serif text-xl text-slate-900">{title}</h2>
      <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
    </div>
  );
}
