/**
 * SchedulePage — vista del cardiólogo: configurar régimen y aprobar plan
 *
 * Ruta sugerida: /cardio-onco/schedule (rol profesional)
 *
 * Flujo:
 *  1. El cardiólogo selecciona el paciente, el régimen terapéutico,
 *     el riesgo basal HFA-ICOS y la fecha de inicio.
 *  2. La aplicación genera el cronograma con generateSchedule().
 *  3. Se previsualiza con SchedulePreview.
 *  4. Al aprobar, se construye el Bundle FHIR (CarePlan + Appointments
 *     + ServiceRequests + Tasks + Communications) y se persiste vía
 *     medplum.executeBatch().
 */

import { useMemo, useState } from 'react';
import { useMedplum, useMedplumProfile } from '@medplum/react';
import { CheckCircleIcon } from '@heroicons/react/24/solid';
import { SchedulePreview } from '../../../components/cardio-onco/SchedulePreview';
import {
  generateSchedule,
  type DrugClass,
  type RiskLevel,
  type ScheduledEvent,
} from '../../../lib/cardio-onco/scheduleEngine';
import { buildScheduleBundle } from '../../../lib/cardio-onco/fhir';

const DRUG_OPTIONS: { value: DrugClass; label: string }[] = [
  { value: 'anthracycline', label: 'Antraciclinas' },
  { value: 'her2-targeted', label: 'Anti-HER2' },
  { value: 'vegf-inhibitor', label: 'Inhibidores de VEGF' },
  { value: 'bcr-abl-inhibitor', label: 'BCR-ABL (ITK 2.ª–3.ª gen)' },
  { value: 'immune-checkpoint-inhibitor', label: 'Inmunoterapia (ICI)' },
  { value: 'proteasome-inhibitor', label: 'Inhibidor de proteasoma' },
  { value: 'fluoropyrimidine', label: 'Fluoropirimidinas' },
  { value: 'androgen-deprivation', label: 'Deprivación androgénica' },
  { value: 'radiotherapy-thoracic', label: 'Radioterapia torácica' },
];

const RISK_OPTIONS: { value: RiskLevel; label: string }[] = [
  { value: 'low', label: 'Bajo' },
  { value: 'moderate', label: 'Moderado' },
  { value: 'high', label: 'Alto' },
  { value: 'very-high', label: 'Muy alto' },
];

export default function SchedulePage(): JSX.Element {
  const medplum = useMedplum();
  const profile = useMedplumProfile();

  const [patientId, setPatientId] = useState<string>('');
  const [riskLevel, setRiskLevel] = useState<RiskLevel>('high');
  const [drugs, setDrugs] = useState<DrugClass[]>(['anthracycline']);
  const [cycles, setCycles] = useState<number>(6);
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [thoracicRT, setThoracicRT] = useState<boolean>(false);
  const [saved, setSaved] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);

  const events: ScheduledEvent[] = useMemo(() => {
    if (!patientId) return [];
    return generateSchedule({
      patient: { reference: `Patient/${patientId}` },
      baseline: { riskLevel, startDate },
      regimen: { drugs, plannedCycles: cycles, thoracicRT },
      currentPhase: 'baseline',
    });
  }, [patientId, riskLevel, drugs, cycles, startDate, thoracicRT]);

  const toggleDrug = (d: DrugClass) => {
    setDrugs((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));
  };

  const handleApprove = async () => {
    if (!patientId || events.length === 0) return;
    setSaving(true);
    setSaved(false);
    try {
      const bundle = buildScheduleBundle({
        patient: { reference: `Patient/${patientId}` },
        events,
        practitioner: profile ? { reference: `Practitioner/${profile.id}` } : undefined,
        riskLevel,
        startDate,
      });
      // Persiste el Bundle: en producción usar medplum.executeBatch(bundle)
      // tras transformarlo a un transaction Bundle con métodos POST.
      await medplum.executeBatch(bundle as never);
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      {/* ============ FORM ============ */}
      <section className="rounded-lg bg-white p-6 ring-1 ring-slate-200">
        <h2 className="font-serif text-2xl text-slate-900">Configurar plan de seguimiento</h2>
        <p className="mt-1 text-sm text-slate-600">
          Definí el régimen terapéutico, el riesgo basal HFA-ICOS y la fecha de inicio. La aplicación
          generará el cronograma según la Guía ESC 2022.
        </p>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Paciente (ID FHIR)
            </label>
            <input
              type="text"
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              placeholder="ej: 0a8d1f2e-..."
              className="mt-2 w-full rounded border-slate-300 font-mono text-sm focus:border-rose-700 focus:ring-rose-700"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Fecha de inicio
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="mt-2 w-full rounded border-slate-300 text-sm focus:border-rose-700 focus:ring-rose-700"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Riesgo HFA-ICOS basal
            </label>
            <select
              value={riskLevel}
              onChange={(e) => setRiskLevel(e.target.value as RiskLevel)}
              className="mt-2 w-full rounded border-slate-300 text-sm focus:border-rose-700 focus:ring-rose-700"
            >
              {RISK_OPTIONS.map((r) => (
                <option key={r.value} value={r.value}>
                  {r.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
              Ciclos previstos
            </label>
            <input
              type="number"
              min={1}
              max={24}
              value={cycles}
              onChange={(e) => setCycles(parseInt(e.target.value || '1', 10))}
              className="mt-2 w-full rounded border-slate-300 text-sm focus:border-rose-700 focus:ring-rose-700"
            />
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700">
            Régimen terapéutico
          </label>
          <div className="mt-2 flex flex-wrap gap-2">
            {DRUG_OPTIONS.map((d) => {
              const active = drugs.includes(d.value);
              return (
                <button
                  key={d.value}
                  type="button"
                  onClick={() => toggleDrug(d.value)}
                  className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                    active
                      ? 'bg-rose-700 text-white ring-1 ring-rose-800'
                      : 'bg-slate-100 text-slate-700 ring-1 ring-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {d.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-4">
          <label className="inline-flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={thoracicRT}
              onChange={(e) => setThoracicRT(e.target.checked)}
              className="rounded border-slate-400 text-rose-700 focus:ring-rose-700"
            />
            Recibió o recibirá radioterapia torácica
          </label>
        </div>
      </section>

      {/* ============ PREVIEW ============ */}
      {events.length > 0 && (
        <div className="mt-8">
          <SchedulePreview events={events} riskLevel={riskLevel} />

          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-lg bg-slate-900 p-5 text-white">
            <div className="text-sm">
              <strong>Aprobar plan:</strong> persiste un{' '}
              <code className="rounded bg-white/10 px-1 font-mono text-xs">CarePlan</code> + recursos
              FHIR asociados y activa las notificaciones automáticas al frontal del paciente.
            </div>
            <button
              type="button"
              onClick={handleApprove}
              disabled={saving || !patientId}
              className="rounded bg-rose-700 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:bg-rose-600 disabled:bg-slate-600"
            >
              {saving ? 'Guardando…' : 'Aprobar y activar plan'}
            </button>
          </div>

          {saved && (
            <div className="mt-4 flex items-center gap-3 rounded-lg bg-emerald-50 p-4 text-emerald-800 ring-1 ring-emerald-200">
              <CheckCircleIcon className="h-5 w-5" />
              <p className="text-sm">
                <strong>Plan activado.</strong> Las notificaciones se enviarán automáticamente según el cronograma.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
