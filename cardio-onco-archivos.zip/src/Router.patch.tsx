/**
 * src/Router.tsx — patch propuesto
 *
 * Mostramos solo las líneas a agregar al Router existente del repo
 * EPA-Bienestar-com/programas. Esto sigue el patrón documentado en:
 *   https://github.com/medplum/medplum/issues/5562
 *   "Add a new route to the routes table"
 *
 * Asumiendo que el Router actual es similar al de medplum/foomedical:
 *   <Routes>
 *     <Route path="/" element={<HomePage />} />
 *     <Route path="/health-record" element={<HealthRecord />} />
 *     ...
 *   </Routes>
 */

import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router-dom';

// ============================================================
// Lazy imports — los nuevos módulos cardio-onco
// ============================================================
const SchedulePage = lazy(
  () => import('./pages/cardio-onco/scheduling/SchedulePage'),
);
const NotificationsPage = lazy(
  () => import('./pages/cardio-onco/notifications/NotificationsPage'),
);

// ============================================================
// Patch al árbol de rutas
// ============================================================
//
//   <Routes>
//     {/* … rutas existentes … */}
//
//     {/* ► Cardio-Oncología (rol profesional) */}
//     <Route
//       path="/cardio-onco/schedule"
//       element={
//         <Suspense fallback={<div>Cargando…</div>}>
//           <SchedulePage />
//         </Suspense>
//       }
//     />
//
//     {/* ► Cardio-Oncología (rol paciente) */}
//     <Route
//       path="/cardio-onco/notifications"
//       element={
//         <Suspense fallback={<div>Cargando…</div>}>
//           <NotificationsPage />
//         </Suspense>
//       }
//     />
//   </Routes>
//
// ============================================================
// Cómo determinar el rol
// ============================================================
// El control de visibilidad se hace por el ProjectMembership de Medplum
// (admin/practitioner/patient). El menú lateral (Header.tsx en el repo
// existente) puede chequear `profile.resourceType` y ocultar/mostrar
// los enlaces correspondientes:
//
//   {profile?.resourceType === 'Practitioner' && (
//     <NavLink to="/cardio-onco/schedule">Cardio-Onco · Agenda</NavLink>
//   )}
//   {profile?.resourceType === 'Patient' && (
//     <NavLink to="/cardio-onco/notifications">Mis recordatorios</NavLink>
//   )}

export default function RouterPatchExample(): JSX.Element {
  return (
    <Routes>
      <Route
        path="/cardio-onco/schedule"
        element={
          <Suspense fallback={<div>Cargando…</div>}>
            <SchedulePage />
          </Suspense>
        }
      />
      <Route
        path="/cardio-onco/notifications"
        element={
          <Suspense fallback={<div>Cargando…</div>}>
            <NotificationsPage />
          </Suspense>
        }
      />
    </Routes>
  );
}
