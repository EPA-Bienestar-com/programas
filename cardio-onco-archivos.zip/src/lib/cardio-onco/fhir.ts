/**
 * FHIR Resource Builders — Cardio-Oncology
 *
 * Convierte los eventos del schedule engine en recursos FHIR R4 conforme
 * al perfilado nacional argentino (Patient_ar_core) y a las guías de
 * implementación de la Red Nacional de Salud Digital (DNGISS).
 *
 * @module lib/cardio-onco/fhir
 */

import type {
  Appointment,
  CarePlan,
  Communication,
  Patient,
  Practitioner,
  Reference,
  ServiceRequest,
  Task,
} from '@medplum/fhirtypes';
import type { ScheduledEvent } from './scheduleEngine';

const SYSTEM = {
  loinc: 'http://loinc.org',
  snomed: 'http://snomed.info/sct',
  ucum: 'http://unitsofmeasure.org',
  ipsAr: 'https://www.argentina.gob.ar/salud/digital/perfiles/ips-ar',
} as const;

/* ============================================================
 * APPOINTMENT — visita presencial programada
 * ============================================================ */

export function buildAppointment(
  event: ScheduledEvent,
  patient: Reference<Patient>,
  practitioner?: Reference<Practitioner>,
): Appointment {
  const start = `${event.scheduledDate}T09:00:00-03:00`;
  const end = `${event.scheduledDate}T09:30:00-03:00`;

  const participants: Appointment['participant'] = [
    { actor: patient, status: 'tentative', required: 'required' },
  ];
  if (practitioner) {
    participants.push({ actor: practitioner, status: 'accepted', required: 'required' });
  }

  return {
    resourceType: 'Appointment',
    status: 'booked',
    serviceCategory: [
      { coding: [{ system: SYSTEM.snomed, code: '394579002', display: 'Cardio-oncology' }] },
    ],
    serviceType: event.fhir.snomed
      ? [{ coding: [{ system: SYSTEM.snomed, code: event.fhir.snomed, display: event.label }] }]
      : undefined,
    appointmentType: {
      coding: [{ system: SYSTEM.snomed, code: '185349003', display: 'Encounter for check up' }],
    },
    description: event.label,
    comment: event.rationale,
    start,
    end,
    minutesDuration: 30,
    participant: participants,
  };
}

/* ============================================================
 * SERVICE REQUEST — solicitud de un estudio diagnóstico
 * ============================================================ */

export function buildServiceRequest(
  event: ScheduledEvent,
  patient: Reference<Patient>,
  requester?: Reference<Practitioner>,
): ServiceRequest {
  return {
    resourceType: 'ServiceRequest',
    status: 'active',
    intent: 'order',
    priority: 'routine',
    category: [
      { coding: [{ system: SYSTEM.snomed, code: '394579002', display: 'Cardio-oncology' }] },
    ],
    code: {
      coding: [
        ...(event.fhir.loinc ? [{ system: SYSTEM.loinc, code: event.fhir.loinc, display: event.label }] : []),
        ...(event.fhir.snomed ? [{ system: SYSTEM.snomed, code: event.fhir.snomed, display: event.label }] : []),
      ],
      text: event.label,
    },
    subject: patient,
    occurrenceDateTime: event.scheduledDate,
    authoredOn: new Date().toISOString(),
    requester,
    note: [{ text: event.rationale }],
  };
}

/* ============================================================
 * TASK — actividad del paciente (PROM, SMBP)
 * ============================================================ */

export function buildTask(
  event: ScheduledEvent,
  patient: Reference<Patient>,
): Task {
  return {
    resourceType: 'Task',
    status: 'requested',
    intent: 'order',
    priority: 'routine',
    code: {
      coding: event.fhir.loinc
        ? [{ system: SYSTEM.loinc, code: event.fhir.loinc, display: event.label }]
        : [],
      text: event.label,
    },
    description: event.rationale,
    for: patient,
    authoredOn: new Date().toISOString(),
    executionPeriod: { start: event.scheduledDate },
    restriction: { period: { end: addDaysISO(event.scheduledDate, 2) } },
  };
}

/* ============================================================
 * CARE PLAN — plan integral cardio-oncológico del paciente
 * ============================================================ */

export interface CarePlanInput {
  patient: Reference<Patient>;
  events: ScheduledEvent[];
  riskLevel: 'low' | 'moderate' | 'high' | 'very-high';
  startDate: string;
  endDate?: string;
  author?: Reference<Practitioner>;
}

export function buildCarePlan(input: CarePlanInput): CarePlan {
  const lastEventDate = input.events[input.events.length - 1]?.scheduledDate;
  return {
    resourceType: 'CarePlan',
    status: 'active',
    intent: 'plan',
    title: 'Plan de Seguimiento Cardio-Oncológico',
    description:
      'Plan longitudinal de vigilancia cardio-oncológica conforme a la Guía ESC 2022 sobre Cardio-Oncología. ' +
      'Comprende fases previa, intra y post tratamiento, con frecuencias específicas por clase farmacológica y nivel de riesgo HFA-ICOS.',
    category: [
      {
        coding: [
          { system: SYSTEM.snomed, code: '394579002', display: 'Cardio-oncology' },
          { system: SYSTEM.loinc, code: '57827-4', display: 'Care plan' },
        ],
      },
    ],
    subject: input.patient,
    period: {
      start: input.startDate,
      end: input.endDate ?? lastEventDate,
    },
    created: new Date().toISOString(),
    author: input.author,
    note: [
      {
        text: `Riesgo HFA-ICOS basal: ${input.riskLevel}. ${input.events.length} actividades programadas.`,
      },
    ],
  };
}

/* ============================================================
 * COMMUNICATION — notificación enviada al paciente
 * ============================================================ */

export interface NotificationInput {
  patient: Reference<Patient>;
  event: ScheduledEvent;
  channel: 'in-app' | 'email' | 'sms' | 'push';
  /** Días de anticipación con que se envía respecto a la fecha del evento */
  leadDaysBefore: number;
}

export function buildNotification(input: NotificationInput): Communication {
  const sentDate = addDaysISO(input.event.scheduledDate, -input.leadDaysBefore);
  const subject = buildNotificationSubject(input.event, input.leadDaysBefore);
  const body = buildNotificationBody(input.event, input.leadDaysBefore);

  return {
    resourceType: 'Communication',
    status: 'preparation',
    category: [
      {
        coding: [
          { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'reminder', display: 'Reminder' },
        ],
      },
    ],
    medium: [
      {
        coding: [
          {
            system: 'http://terminology.hl7.org/CodeSystem/v3-ParticipationMode',
            code: input.channel === 'email' ? 'EMAILWRIT' : input.channel === 'sms' ? 'SMSWRIT' : 'ELECTRONIC',
            display: input.channel,
          },
        ],
      },
    ],
    subject: input.patient,
    recipient: [input.patient],
    topic: { text: subject },
    payload: [{ contentString: body }],
    sent: sentDate,
  };
}

/* ============================================================
 * HELPERS — formato de notificaciones
 * ============================================================ */

function buildNotificationSubject(event: ScheduledEvent, leadDays: number): string {
  if (leadDays === 0) {
    return `Hoy: ${event.label}`;
  }
  if (leadDays === 1) {
    return `Mañana: ${event.label}`;
  }
  return `En ${leadDays} días: ${event.label}`;
}

function buildNotificationBody(event: ScheduledEvent, leadDays: number): string {
  const when =
    leadDays === 0
      ? 'Hoy es el día'
      : leadDays === 1
        ? 'Mañana'
        : `En ${leadDays} días, el ${formatHumanDate(event.scheduledDate)},`;

  if (event.study === 'questionnaire-proms') {
    return `${when} te pediremos que respondas un cuestionario corto sobre cómo te sentís. Te toma menos de 2 minutos y le permite a tu equipo médico actuar a tiempo.`;
  }

  if (event.study === 'home-bp') {
    return `${when} corresponde tu medición domiciliaria de presión arterial. Recordá hacerla en reposo, sentado/a, después de 5 minutos sin hablar.`;
  }

  if (event.requiresInPersonVisit) {
    return `${when} tenés programado: ${event.label}. Te esperamos en el servicio de Cardio-Oncología. Si no podés asistir, comunicate con anticipación.`;
  }

  return `${when} corresponde realizar: ${event.label}.`;
}

function addDaysISO(iso: string, days: number): string {
  const d = new Date(iso + (iso.length === 10 ? 'T00:00:00Z' : ''));
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function formatHumanDate(iso: string): string {
  const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
                  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const d = new Date(iso + 'T00:00:00Z');
  return `${d.getUTCDate()} de ${months[d.getUTCMonth()]}`;
}

/* ============================================================
 * BATCH BUILDER — construye un Bundle FHIR completo
 * ============================================================ */

export interface BuildBundleInput {
  patient: Reference<Patient>;
  events: ScheduledEvent[];
  practitioner?: Reference<Practitioner>;
  riskLevel: CarePlanInput['riskLevel'];
  startDate: string;
}

export function buildScheduleBundle(input: BuildBundleInput) {
  const carePlan = buildCarePlan({
    patient: input.patient,
    events: input.events,
    riskLevel: input.riskLevel,
    startDate: input.startDate,
    author: input.practitioner,
  });

  const resources = input.events.flatMap((event) => {
    const rs: Array<Appointment | ServiceRequest | Task | Communication> = [];

    // Recurso clínico principal
    if (event.fhir.resourceType === 'Appointment') {
      rs.push(buildAppointment(event, input.patient, input.practitioner));
    } else if (event.fhir.resourceType === 'ServiceRequest') {
      rs.push(buildServiceRequest(event, input.patient, input.practitioner));
    } else if (event.fhir.resourceType === 'Task') {
      rs.push(buildTask(event, input.patient));
    }

    // Notificaciones programadas
    for (const lead of event.reminderLeadDaysBefore) {
      rs.push(
        buildNotification({
          patient: input.patient,
          event,
          channel: 'in-app',
          leadDaysBefore: lead,
        }),
      );
    }
    return rs;
  });

  return {
    resourceType: 'Bundle',
    type: 'collection',
    entry: [{ resource: carePlan }, ...resources.map((r) => ({ resource: r }))],
  };
}
