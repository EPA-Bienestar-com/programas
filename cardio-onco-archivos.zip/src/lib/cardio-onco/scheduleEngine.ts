/**
 * Cardio-Oncology Schedule Engine
 *
 * Genera el cronograma de seguimiento cardio-oncológico personalizado
 * a partir del régimen terapéutico, el riesgo basal HFA-ICOS y la fase
 * del tratamiento. Las frecuencias derivan de las Tablas 7-14 de la
 * Guía ESC 2022 sobre Cardio-Oncología.
 *
 * Referencias:
 *  - ESC Guidelines on cardio-oncology, Eur Heart J 2022;43:4229-4361
 *  - HFA-ICOS Risk Assessment Tools
 *
 * @module lib/cardio-onco/scheduleEngine
 */

import type { Patient, Reference } from '@medplum/fhirtypes';

/* ============================================================
 * TIPOS Y ENUMS
 * ============================================================ */

export type RiskLevel = 'low' | 'moderate' | 'high' | 'very-high';

export type Phase = 'baseline' | 'on-treatment' | 'end-of-treatment' | 'survivorship';

export type DrugClass =
  | 'anthracycline'
  | 'her2-targeted'
  | 'vegf-inhibitor'
  | 'bcr-abl-inhibitor'
  | 'immune-checkpoint-inhibitor'
  | 'proteasome-inhibitor'
  | 'fluoropyrimidine'
  | 'androgen-deprivation'
  | 'radiotherapy-thoracic';

export type StudyType =
  | 'ecg'
  | 'echo-2d'                  // Echocardiogram with FEVI
  | 'echo-gls'                 // Echocardiogram with Global Longitudinal Strain
  | 'troponin'                 // High-sensitivity troponin
  | 'bnp'                      // BNP / NT-proBNP
  | 'lipid-panel'
  | 'hba1c'
  | 'home-bp'                  // SMBP self-measured BP
  | 'cardiac-mri'
  | 'questionnaire-proms'      // Patient-reported outcome measures
  | 'cardiology-consult';

export interface ScheduledEvent {
  /** Identificador estable derivado del plan */
  id: string;

  /** Tipo de estudio o actividad */
  study: StudyType;

  /** Fecha programada (ISO 8601, YYYY-MM-DD) */
  scheduledDate: string;

  /** Fase del tratamiento en que ocurre */
  phase: Phase;

  /** Etiqueta humana legible */
  label: string;

  /** Justificación clínica y referencia ESC */
  rationale: string;

  /** Si requiere visita presencial */
  requiresInPersonVisit: boolean;

  /** Días de anticipación con que se envía recordatorio */
  reminderLeadDaysBefore: number[];

  /** Vinculación a recursos FHIR */
  fhir: {
    resourceType: 'Appointment' | 'ServiceRequest' | 'Task';
    /** LOINC del estudio */
    loinc?: string;
    /** SNOMED CT del procedimiento */
    snomed?: string;
  };
}

export interface ScheduleInput {
  patient: Reference<Patient>;
  baseline: {
    riskLevel: RiskLevel;
    /** Fecha desde la cual se proyecta el plan */
    startDate: string;
  };
  regimen: {
    drugs: DrugClass[];
    /** Cantidad total de ciclos previstos (si aplica) */
    plannedCycles?: number;
    /** Días entre ciclos (default 21) */
    cycleIntervalDays?: number;
    /** Si recibió o recibirá radioterapia torácica */
    thoracicRT?: boolean;
  };
  /** Fase actual del paciente */
  currentPhase: Phase;
}

/* ============================================================
 * CATÁLOGO LOINC / SNOMED
 * ============================================================ */

const CODES = {
  ecg: { loinc: '11524-6', snomed: '29303009', label: 'ECG de 12 derivaciones' },
  echo2d: { loinc: '8806-2', snomed: '40701008', label: 'Ecocardiograma 2D con FEVI' },
  echoGls: { loinc: '93646-8', snomed: '40701008', label: 'Ecocardiograma con SLG (speckle tracking)' },
  troponin: { loinc: '67151-1', snomed: '127081002', label: 'Troponina cardíaca de alta sensibilidad' },
  bnp: { loinc: '33762-6', snomed: '127080001', label: 'NT-proBNP' },
  lipid: { loinc: '57698-3', snomed: '252150009', label: 'Perfil lipídico' },
  hba1c: { loinc: '4548-4', snomed: '43396009', label: 'Hemoglobina glicosilada' },
  homeBP: { loinc: '85354-9', snomed: '413153004', label: 'Auto-medición de presión arterial domiciliaria' },
  cardiacMRI: { loinc: '24590-4', snomed: '241621007', label: 'Resonancia magnética cardíaca' },
  proms: { loinc: '86923-0', snomed: '273249006', label: 'Cuestionario de síntomas (PROMs)' },
  consult: { loinc: '11488-4', snomed: '11429006', label: 'Consulta cardiológica' },
} as const;

/* ============================================================
 * REGLAS DE FRECUENCIA POR CLASE FARMACOLÓGICA
 * ============================================================ */

interface FrequencyRule {
  study: StudyType;
  /** Cada cuántos ciclos (si aplica) */
  everyNCycles?: number;
  /** Cada cuántos días (si aplica) */
  everyNDays?: number;
  /** Si solo aplica en alto riesgo */
  highRiskOnly?: boolean;
  /** Justificación clínica con referencia ESC */
  rationale: string;
}

/**
 * Reglas de vigilancia INTRA-tratamiento por clase farmacológica.
 * Derivadas de las Tablas 7-14 de la Guía ESC 2022.
 */
const ON_TREATMENT_RULES: Record<DrugClass, FrequencyRule[]> = {
  anthracycline: [
    {
      study: 'troponin',
      everyNCycles: 1,
      highRiskOnly: false,
      rationale: 'ESC 2022 §3 — Troponina pre-ciclo en alto riesgo; basal y final si moderado',
    },
    {
      study: 'echo-gls',
      everyNCycles: 2,
      rationale: 'ESC 2022 Tabla 7 — Eco con SLG cada 2 ciclos en alto riesgo',
    },
    {
      study: 'bnp',
      everyNCycles: 2,
      rationale: 'ESC 2022 §3 — Péptidos natriuréticos en seguimiento de alto riesgo',
    },
  ],
  'her2-targeted': [
    {
      study: 'echo-gls',
      everyNDays: 90,
      rationale: 'ESC 2022 Tabla 8 — Eco cada 3 meses durante terapia anti-HER2',
    },
    {
      study: 'troponin',
      everyNDays: 90,
      highRiskOnly: true,
      rationale: 'ESC 2022 Tabla 8 — Troponina cada 3 meses si alto riesgo',
    },
  ],
  'vegf-inhibitor': [
    {
      study: 'home-bp',
      everyNDays: 7,
      rationale: 'ESC 2022 Tabla 11 — SMBP semanal en pacientes con VEGFi',
    },
    {
      study: 'echo-2d',
      everyNDays: 120,
      highRiskOnly: true,
      rationale: 'ESC 2022 §6.3 — Eco cada 4 meses en alto riesgo con VEGFi',
    },
  ],
  'bcr-abl-inhibitor': [
    {
      study: 'ecg',
      everyNDays: 90,
      rationale: 'ESC 2022 Tabla 13 — ECG cada 3 meses (riesgo de QT y vasculopatía)',
    },
    {
      study: 'echo-2d',
      everyNDays: 180,
      highRiskOnly: true,
      rationale: 'ESC 2022 §6.5 — Eco semestral en alto riesgo con ITK BCR-ABL',
    },
  ],
  'immune-checkpoint-inhibitor': [
    {
      study: 'troponin',
      everyNCycles: 1,
      rationale: 'ESC 2022 Tabla 14 — Troponina antes de cada infusión durante los primeros 4 ciclos (riesgo de miocarditis)',
    },
    {
      study: 'ecg',
      everyNCycles: 1,
      rationale: 'ESC 2022 Tabla 14 — ECG pre-infusión en los primeros 4 ciclos',
    },
  ],
  'proteasome-inhibitor': [
    {
      study: 'echo-2d',
      everyNDays: 90,
      rationale: 'ESC 2022 §6.6 — Vigilancia ecocardiográfica trimestral con carfilzomib',
    },
    {
      study: 'home-bp',
      everyNDays: 7,
      rationale: 'ESC 2022 §6.6 — SMBP semanal por riesgo de HTA',
    },
  ],
  fluoropyrimidine: [
    {
      study: 'ecg',
      everyNCycles: 1,
      rationale: 'ESC 2022 §6.4 — ECG ante síntomas; vigilancia clínica de vasoespasmo',
    },
  ],
  'androgen-deprivation': [
    {
      study: 'lipid-panel',
      everyNDays: 180,
      rationale: 'ESC 2022 Tabla 12 — Perfil lipídico semestral',
    },
    {
      study: 'hba1c',
      everyNDays: 180,
      rationale: 'ESC 2022 Tabla 12 — HbA1c semestral',
    },
  ],
  'radiotherapy-thoracic': [
    // RT no se monitoriza por ciclo sino post-tratamiento
  ],
};

/* ============================================================
 * GENERADOR DE CRONOGRAMA
 * ============================================================ */

const STUDY_META: Record<StudyType, { code: typeof CODES[keyof typeof CODES]; visit: boolean; reminders: number[] }> = {
  ecg: { code: CODES.ecg, visit: true, reminders: [3, 1] },
  'echo-2d': { code: CODES.echo2d, visit: true, reminders: [7, 1] },
  'echo-gls': { code: CODES.echoGls, visit: true, reminders: [7, 1] },
  troponin: { code: CODES.troponin, visit: true, reminders: [2, 0] },
  bnp: { code: CODES.bnp, visit: true, reminders: [2, 0] },
  'lipid-panel': { code: CODES.lipid, visit: true, reminders: [3, 1] },
  hba1c: { code: CODES.hba1c, visit: true, reminders: [3, 1] },
  'home-bp': { code: CODES.homeBP, visit: false, reminders: [0] },
  'cardiac-mri': { code: CODES.cardiacMRI, visit: true, reminders: [7, 2] },
  'questionnaire-proms': { code: CODES.proms, visit: false, reminders: [0] },
  'cardiology-consult': { code: CODES.consult, visit: true, reminders: [7, 2, 0] },
};

function addDays(iso: string, days: number): string {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function buildEvent(
  patientRef: string,
  study: StudyType,
  date: string,
  phase: Phase,
  rationale: string,
): ScheduledEvent {
  const meta = STUDY_META[study];
  const id = `${patientRef}|${study}|${date}`.replace(/\s+/g, '_');
  const fhirType: 'Appointment' | 'ServiceRequest' | 'Task' =
    study === 'questionnaire-proms' || study === 'home-bp'
      ? 'Task'
      : study === 'cardiology-consult'
        ? 'Appointment'
        : 'ServiceRequest';

  return {
    id,
    study,
    scheduledDate: date,
    phase,
    label: meta.code.label,
    rationale,
    requiresInPersonVisit: meta.visit,
    reminderLeadDaysBefore: meta.reminders,
    fhir: { resourceType: fhirType, loinc: meta.code.loinc, snomed: meta.code.snomed },
  };
}

/**
 * Construye el cronograma completo para un paciente cardio-oncológico.
 * Devuelve eventos ordenados por fecha.
 */
export function generateSchedule(input: ScheduleInput): ScheduledEvent[] {
  const events: ScheduledEvent[] = [];
  const start = input.baseline.startDate;
  const cycleDays = input.regimen.cycleIntervalDays ?? 21;
  const cycles = input.regimen.plannedCycles ?? 6;
  const isHigh = input.baseline.riskLevel === 'high' || input.baseline.riskLevel === 'very-high';
  const patientRef = input.patient.reference ?? 'Patient/unknown';

  /* -------- FASE BASAL -------- */
  // ESC 2022 §2: evaluación basal independiente del riesgo
  events.push(
    buildEvent(patientRef, 'ecg', start, 'baseline', 'ESC 2022 §2 — ECG basal'),
    buildEvent(patientRef, 'echo-gls', start, 'baseline', 'ESC 2022 §2 — Eco con FEVI y SLG basal'),
    buildEvent(patientRef, 'troponin', start, 'baseline', 'ESC 2022 §2 — Troponina basal'),
    buildEvent(patientRef, 'bnp', start, 'baseline', 'ESC 2022 §2 — Péptidos natriuréticos basales'),
  );
  // En alto y muy alto riesgo, consulta cardiológica antes de iniciar
  if (isHigh) {
    events.push(
      buildEvent(
        patientRef,
        'cardiology-consult',
        start,
        'baseline',
        'ESC 2022 §2 — Derivación obligatoria a cardiología en alto/muy alto riesgo',
      ),
    );
  }

  /* -------- FASE INTRA-TRATAMIENTO -------- */
  for (const drug of input.regimen.drugs) {
    const rules = ON_TREATMENT_RULES[drug] ?? [];
    for (const rule of rules) {
      if (rule.highRiskOnly && !isHigh) continue;

      if (rule.everyNCycles) {
        for (let cycle = 1; cycle <= cycles; cycle += rule.everyNCycles) {
          const date = addDays(start, cycle * cycleDays);
          events.push(buildEvent(patientRef, rule.study, date, 'on-treatment', rule.rationale));
        }
      } else if (rule.everyNDays) {
        const totalDays = cycles * cycleDays;
        for (let d = rule.everyNDays; d <= totalDays; d += rule.everyNDays) {
          events.push(buildEvent(patientRef, rule.study, addDays(start, d), 'on-treatment', rule.rationale));
        }
      }
    }
  }

  // PROMs semanales durante todo el tratamiento (todas las clases)
  if (input.regimen.drugs.length > 0) {
    const totalDays = cycles * cycleDays;
    for (let d = 7; d <= totalDays; d += 7) {
      events.push(
        buildEvent(
          patientRef,
          'questionnaire-proms',
          addDays(start, d),
          'on-treatment',
          'ESC 2022 §3 — Captura semanal de síntomas reportados por el paciente',
        ),
      );
    }
  }

  /* -------- FASE POST-TRATAMIENTO -------- */
  const endOfTx = addDays(start, cycles * cycleDays);

  // Reevaluación a 3 y 12 meses (alto riesgo)
  if (isHigh) {
    const m3 = addDays(endOfTx, 90);
    const m12 = addDays(endOfTx, 365);
    events.push(
      buildEvent(patientRef, 'echo-gls', m3, 'end-of-treatment', 'ESC 2022 §10 — Reevaluación a 3 meses post-tratamiento'),
      buildEvent(patientRef, 'troponin', m3, 'end-of-treatment', 'ESC 2022 §10 — Troponina a 3 meses'),
      buildEvent(patientRef, 'echo-gls', m12, 'survivorship', 'ESC 2022 §10 — Reevaluación a 12 meses'),
      buildEvent(patientRef, 'bnp', m12, 'survivorship', 'ESC 2022 §10 — NT-proBNP a 12 meses'),
    );
  } else {
    const m12 = addDays(endOfTx, 365);
    events.push(
      buildEvent(patientRef, 'echo-2d', m12, 'survivorship', 'ESC 2022 §10 — Control anual'),
    );
  }

  // Reestratificación a 5 años en pacientes con antraciclinas o RT torácica
  const requiresFiveYearReeval = input.regimen.drugs.includes('anthracycline') || input.regimen.thoracicRT;
  if (requiresFiveYearReeval) {
    events.push(
      buildEvent(
        patientRef,
        'cardiology-consult',
        addDays(endOfTx, 365 * 5),
        'survivorship',
        'ESC 2022 §10 — Reestratificación a 5 años (antraciclinas / RT torácica)',
      ),
      buildEvent(
        patientRef,
        'echo-gls',
        addDays(endOfTx, 365 * 5),
        'survivorship',
        'ESC 2022 §10 — Eco a 5 años',
      ),
    );
  }

  /* -------- ORDENAR Y DEDUPLICAR -------- */
  const dedup = new Map<string, ScheduledEvent>();
  for (const e of events) dedup.set(e.id, e);
  return Array.from(dedup.values()).sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate));
}

/* ============================================================
 * RESUMEN POR FASE — para UI
 * ============================================================ */

export function summarizeByPhase(events: ScheduledEvent[]) {
  return events.reduce(
    (acc, e) => {
      acc[e.phase] = (acc[e.phase] || 0) + 1;
      return acc;
    },
    { baseline: 0, 'on-treatment': 0, 'end-of-treatment': 0, survivorship: 0 } as Record<Phase, number>,
  );
}

export function summarizeByStudy(events: ScheduledEvent[]) {
  return events.reduce(
    (acc, e) => {
      acc[e.study] = (acc[e.study] || 0) + 1;
      return acc;
    },
    {} as Record<StudyType, number>,
  );
}
