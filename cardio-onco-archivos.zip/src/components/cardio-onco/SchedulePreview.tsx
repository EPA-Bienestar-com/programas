/**
 * SchedulePreview — Cronograma cardio-oncológico
 *
 * Render visual del cronograma generado por scheduleEngine, agrupado
 * por fase y con detalle clínico/FHIR para que el cardiólogo pueda
 * revisar y aprobar el plan antes de su persistencia.
 */

import {
  CalendarDaysIcon,
  HeartIcon,
  BellAlertIcon,
  DocumentTextIcon,
  ClockIcon,
  CheckBadgeIcon,
} from '@heroicons/react/24/outline';
import type { ScheduledEvent, Phase, StudyType } from '../../lib/cardio-onco/scheduleEngine';

interface Props {
  events: ScheduledEvent[];
  riskLevel: 'low' | 'moderate' | 'high' | 'very-high';
  patientName?: string;
}

const PHASE_META: Record<Phase, { label: string; tag: string; bg: string; ring: string }> = {
  baseline: {
    label: 'Fase Previa — Evaluación basal',
    tag: 'PREVIA',
    bg: 'bg-rose-50',
    ring: 'ring-rose-700',
  },
  'on-treatment': {
    label: 'Fase Intra — Vigilancia activa',
    tag: 'INTRA',
    bg: 'bg-amber-50',
    ring: 'ring-amber-700',
  },
  'end-of-treatment': {
    label: 'Fin de tratamiento',
    tag: 'POST 0–3M',
    bg: 'bg-slate-100',
    ring: 'ring-slate-700',
  },
  survivorship: {
    label: 'Fase Post — Seguimiento de supervivientes',
    tag: 'POST 3M+',
    bg: 'bg-emerald-50',
    ring: 'ring-emerald-700',
  },
};

const STUDY_LABEL: Record<StudyType, string> = {
  ecg: 'ECG',
  'echo-2d': 'Eco 2D',
  'echo-gls': 'Eco + SLG',
  troponin: 'Troponina HS',
  bnp: 'NT-proBNP',
  'lipid-panel': 'Perfil lipídico',
  hba1c: 'HbA1c',
  'home-bp': 'PA domiciliaria',
  'cardiac-mri': 'RM cardíaca',
  'questionnaire-proms': 'PROMs',
  'cardiology-consult': 'Consulta cardio',
};

const RISK_COLOR: Record<Props['riskLevel'], string> = {
  low: 'bg-emerald-100 text-emerald-800 ring-emerald-700/30',
  moderate: 'bg-amber-100 text-amber-800 ring-amber-700/30',
  high: 'bg-rose-100 text-rose-800 ring-rose-700/30',
  'very-high': 'bg-red-200 text-red-900 ring-red-800/40',
};

export function SchedulePreview({ events, riskLevel, patientName }: Props): JSX.Element {
  const grouped = groupByPhase(events);
  const totalReminders = events.reduce((s, e) => s + e.reminderLeadDaysBefore.length, 0);

  return (
    <div className="mx-auto max-w-6xl space-y-8 px-6 py-10 font-sans">
      {/* ============ HEADER ============ */}
      <header className="border-b border-slate-200 pb-6">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-rose-700">
          <HeartIcon className="h-4 w-4" />
          Programa Cardio-Oncológico — Plan de Seguimiento
        </div>
        <h1 className="mt-3 font-serif text-3xl text-slate-900">
          Cronograma de seguimiento{patientName ? ` — ${patientName}` : ''}
        </h1>
        <div className="mt-4 flex flex-wrap gap-3 text-sm text-slate-600">
          <span className={`rounded px-2.5 py-1 text-xs font-semibold uppercase ring-1 ${RISK_COLOR[riskLevel]}`}>
            Riesgo HFA-ICOS · {riskLevel}
          </span>
          <span className="rounded bg-slate-100 px-2.5 py-1 text-xs uppercase tracking-wider ring-1 ring-slate-300">
            {events.length} actividades
          </span>
          <span className="rounded bg-slate-100 px-2.5 py-1 text-xs uppercase tracking-wider ring-1 ring-slate-300">
            {totalReminders} notificaciones programadas
          </span>
          <span className="rounded bg-slate-900 px-2.5 py-1 text-xs uppercase tracking-wider text-white">
            HL7 FHIR R4
          </span>
        </div>
      </header>

      {/* ============ KPIs ============ */}
      <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat icon={<CalendarDaysIcon className="h-5 w-5" />} label="Eventos basales" value={grouped.baseline.length} />
        <Stat
          icon={<ClockIcon className="h-5 w-5" />}
          label="Vigilancia intra"
          value={grouped['on-treatment'].length}
        />
        <Stat
          icon={<DocumentTextIcon className="h-5 w-5" />}
          label="Reevaluación 0–3m"
          value={grouped['end-of-treatment'].length}
        />
        <Stat
          icon={<CheckBadgeIcon className="h-5 w-5" />}
          label="Supervivencia"
          value={grouped.survivorship.length}
        />
      </section>

      {/* ============ PHASES ============ */}
      {(['baseline', 'on-treatment', 'end-of-treatment', 'survivorship'] as Phase[]).map((phase) => {
        const phaseEvents = grouped[phase];
        if (phaseEvents.length === 0) return null;

        const meta = PHASE_META[phase];
        return (
          <section key={phase} className={`rounded-lg ${meta.bg} ring-1 ${meta.ring}/30`}>
            <header className="flex items-center justify-between border-b border-current/10 px-6 py-4">
              <div>
                <span className="text-xs font-mono font-semibold tracking-widest text-slate-700">
                  {meta.tag}
                </span>
                <h2 className="font-serif text-xl text-slate-900">{meta.label}</h2>
              </div>
              <span className="rounded-full bg-white px-3 py-1 text-xs font-medium text-slate-700 ring-1 ring-slate-300">
                {phaseEvents.length} eventos
              </span>
            </header>
            <ul className="divide-y divide-slate-200">
              {phaseEvents.map((e) => (
                <EventRow key={e.id} event={e} />
              ))}
            </ul>
          </section>
        );
      })}

      {/* ============ FOOTER ============ */}
      <footer className="rounded border border-dashed border-slate-300 bg-slate-50 p-4 text-xs text-slate-600">
        <p>
          <strong className="text-slate-900">Cronograma derivado.</strong> Este plan se generó automáticamente
          a partir del régimen terapéutico declarado y del riesgo HFA-ICOS basal, conforme a la Guía ESC 2022.
          Antes de su persistencia como CarePlan FHIR, el cardiólogo responsable debe revisar y aprobar cada
          actividad. Las notificaciones se enviarán al frontal del paciente
          en <code className="rounded bg-white px-1 py-0.5 font-mono">programas.epa-bienestar.com.ar</code>.
        </p>
      </footer>
    </div>
  );
}

/* ============ Sub-components ============ */

function Stat({ icon, label, value }: { icon: JSX.Element; label: string; value: number }) {
  return (
    <div className="rounded border border-slate-200 bg-white p-4">
      <div className="flex items-center gap-2 text-slate-500">
        {icon}
        <span className="text-xs font-medium uppercase tracking-wider">{label}</span>
      </div>
      <div className="mt-2 font-serif text-3xl text-slate-900">{value}</div>
    </div>
  );
}

function EventRow({ event }: { event: ScheduledEvent }) {
  return (
    <li className="grid grid-cols-12 gap-4 px-6 py-4 transition hover:bg-white/60">
      <div className="col-span-2 font-mono text-sm text-slate-700">
        {formatDate(event.scheduledDate)}
      </div>
      <div className="col-span-2">
        <span className="inline-flex items-center rounded bg-slate-900 px-2 py-0.5 text-xs font-medium text-white">
          {STUDY_LABEL[event.study]}
        </span>
      </div>
      <div className="col-span-6">
        <div className="text-sm font-medium text-slate-900">{event.label}</div>
        <div className="mt-1 text-xs italic text-slate-600">{event.rationale}</div>
        {event.fhir.loinc && (
          <div className="mt-2 flex gap-3 text-[11px] font-mono text-slate-500">
            <span>LOINC {event.fhir.loinc}</span>
            {event.fhir.snomed && <span>SNOMED {event.fhir.snomed}</span>}
            <span className="rounded bg-slate-100 px-1.5 ring-1 ring-slate-200">
              {event.fhir.resourceType}
            </span>
          </div>
        )}
      </div>
      <div className="col-span-2 flex items-start justify-end">
        <div className="flex flex-col items-end gap-1">
          {event.requiresInPersonVisit && (
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-700">
              Presencial
            </span>
          )}
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <BellAlertIcon className="h-3.5 w-3.5" />
            {event.reminderLeadDaysBefore.length} aviso
            {event.reminderLeadDaysBefore.length === 1 ? '' : 's'}
          </div>
        </div>
      </div>
    </li>
  );
}

function groupByPhase(events: ScheduledEvent[]) {
  const acc: Record<Phase, ScheduledEvent[]> = {
    baseline: [],
    'on-treatment': [],
    'end-of-treatment': [],
    survivorship: [],
  };
  for (const e of events) acc[e.phase].push(e);
  return acc;
}

function formatDate(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' });
}
