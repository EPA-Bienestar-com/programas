# Entregable 3 — Calendarización & Notificaciones

**Repositorio destino:** `https://github.com/EPA-Bienestar-com/programas`
**Stack confirmado:** React 18 · TypeScript · Vite · TailwindCSS · Headless UI · Heroicons · `@medplum/react` · `@medplum/core` · `@medplum/fhirtypes` · React Router v6

Este paquete propone agregar al repositorio existente —forkeado de `medplum/foomedical`— dos rutas nuevas y un bot server-side, sin alterar la arquitectura ni el contrato FHIR del backend Medplum.

---

## 1. Estructura propuesta (mismo árbol que `foomedical`)

```
programas/
├─ src/
│  ├─ Router.tsx              ← se le agregan 2 routes (ver Router.patch.tsx)
│  ├─ components/
│  │  └─ cardio-onco/
│  │     └─ SchedulePreview.tsx        ← componente reutilizable
│  ├─ lib/
│  │  └─ cardio-onco/
│  │     ├─ scheduleEngine.ts          ← motor de cronograma (ESC 2022)
│  │     └─ fhir.ts                    ← builders Appointment/ServiceRequest/...
│  └─ pages/
│     └─ cardio-onco/
│        ├─ scheduling/SchedulePage.tsx        ← rol PROFESIONAL
│        └─ notifications/NotificationsPage.tsx ← rol PACIENTE
└─ programas/
   └─ cardio-onco/
      └─ notification-bot.ts          ← Medplum Bot (cron)
```

**Por qué esta ruta:** el repositorio ya tiene `src/pages/`, `src/components/`, `src/lib/` y un directorio `programas/` para bots. Agregamos un sub-namespace `cardio-onco/` en cada uno para mantener todo el módulo aislado y fácil de quitar/portar a otra "marca blanca".

---

## 2. Recursos FHIR utilizados

| Recurso          | Cuándo se crea                              | Vinculación                |
| ---------------- | ------------------------------------------- | -------------------------- |
| `CarePlan`       | Una vez por paciente al aprobar el plan     | título + período + autor   |
| `Appointment`    | Por cada visita presencial (consulta cardio)| LOINC + SNOMED + slots     |
| `ServiceRequest` | Por cada estudio diagnóstico programado     | LOINC + SNOMED + occurrence|
| `Task`           | Por cada actividad del paciente (PROM/SMBP) | LOINC + executionPeriod    |
| `Communication`  | 2-3 por evento (días previos + día)         | recipient + topic + payload|
| `AuditEvent`     | Por cada despacho de notificación           | trazabilidad regulatoria   |

Codificación: **LOINC** (laboratorio/imagen), **SNOMED CT** (procedimientos), **UCUM** (unidades). Todos los recursos cumplen FHIR R4 y son compatibles con el perfilado nacional (`Patient_ar_core`) cuando se aplique.

---

## 3. Flujo end-to-end

```
┌──────────────────┐  1. Configura régimen   ┌──────────────────┐
│  Cardiólogo      │ ───────────────────────►│  SchedulePage    │
│  (rol prof)      │                         │  (UI React)      │
└──────────────────┘                         └────────┬─────────┘
                                                      │
                                 2. generateSchedule()│
                                                      ▼
                                             ┌──────────────────┐
                                             │ scheduleEngine   │
                                             │ (ESC 2022 rules) │
                                             └────────┬─────────┘
                                                      │
                                           3. Eventos[] derivados
                                                      ▼
                                             ┌──────────────────┐
                                 4. Aprueba  │ buildScheduleBundle │
                                             │  (transaction)   │
                                             └────────┬─────────┘
                                                      │
                                         5. medplum.executeBatch()
                                                      ▼
                                         ┌─────────────────────────┐
                                         │  Medplum / FHIR Server  │
                                         │  CarePlan + Appoint. +  │
                                         │  ServiceRequest + Task  │
                                         │  + Communication (×N)   │
                                         └────────┬────────────────┘
                                                  │
                             6. Cron diario       │
                                                  ▼
                                         ┌─────────────────────────┐
                                         │  notification-bot.ts    │
                                         │  busca Communication    │
                                         │  status='preparation'   │
                                         │  con sent en 24h        │
                                         └────────┬────────────────┘
                                                  │
                               7. Despacha por canal (in-app/email/sms)
                                                  ▼
                                         ┌─────────────────────────┐
                                         │  NotificationsPage      │
                                         │  (frontal paciente en   │
                                         │  programas.epa-...)     │
                                         └─────────────────────────┘
```

---

## 4. Pasos para integrar (PR sobre `master`)

1. **Copiar archivos** a sus rutas:
   - `src/lib/cardio-onco/scheduleEngine.ts`
   - `src/lib/cardio-onco/fhir.ts`
   - `src/components/cardio-onco/SchedulePreview.tsx`
   - `src/pages/cardio-onco/scheduling/SchedulePage.tsx`
   - `src/pages/cardio-onco/notifications/NotificationsPage.tsx`

2. **Patchear `src/Router.tsx`** según `Router.patch.tsx`. Agregar dos `<Route>`:
   - `/cardio-onco/schedule` → `SchedulePage` (gated a `Practitioner`)
   - `/cardio-onco/notifications` → `NotificationsPage` (gated a `Patient`)

3. **Patchear el menú lateral** (probablemente `src/components/Header.tsx`) para mostrar el enlace según el `resourceType` del profile.

4. **Crear el Bot en Medplum:**
   - Subir `programas/cardio-onco/notification-bot.ts` como nuevo Bot.
   - Configurar Subscription tipo cron: `0 9 * * *` (todos los días 09:00 ART).
   - Asignar permisos `Project Admin → Bots → cardio-onco-notifications`.

5. **No requiere migraciones de schema** — solo nuevos recursos FHIR estándar, ya soportados por el backend Medplum existente.

---

## 5. Cómo extender (para otras marcas blancas)

El motor de reglas (`scheduleEngine.ts`) está separado del UI y del FHIR, así que para personalizar:

- **Agregar nuevo tipo de droga:** sumar entrada en `ON_TREATMENT_RULES`.
- **Cambiar frecuencia:** modificar la regla, sin tocar UI ni FHIR.
- **Agregar nuevo estudio:** sumar entrada en `STUDY_META` con su LOINC/SNOMED.
- **Nuevo canal de notificación:** sumar `case` en `dispatchOne()` del bot.

El componente `SchedulePreview` y la página `SchedulePage` son agnósticos al contenido específico de las reglas — todo se deriva del schema de tipos.

---

## 6. Testing recomendado

```bash
# Unit tests del engine (puro, sin dependencias)
npm run test src/lib/cardio-onco/scheduleEngine.test.ts

# Smoke test del UI con Cypress (ya configurado en el repo)
npm run cypress:open -- --spec "e2e/cardio-onco/*.cy.ts"
```

Tests sugeridos:
- `scheduleEngine.test.ts`: dado régimen X + riesgo Y → produce N eventos esperados.
- `fhir.test.ts`: el bundle generado es un FHIR R4 válido (LOINC presente, etc.).
- `notification-bot.test.ts`: dry-run con fixture de Communications.

---

## 7. KPIs que el módulo habilita medir

Esta implementación es la fuente de datos viva para los KPIs declarados en la web preliminar (Entregable 2):

- **CUM-01 Adherencia ecocardiográfica** ← `ServiceRequest.status='completed'` / total
- **CUM-02 Biomarcadores pre-ciclo** ← idem para Troponina + BNP
- **CUM-03 Tasa de respuesta PROMs** ← `Task.status='completed'` / total Task PROM
- **CUM-04 Adherencia SMBP** ← `Observation` (presión arterial) / semana
- **RES-02 Tiempo a derivación** ← timestamp Communication → timestamp Encounter

Todas estas métricas se computan con queries FHIR estándar sobre los recursos que este módulo crea.

---

## 8. Reglas ESC 2022 implementadas (resumen)

| Clase farmacológica | Frecuencia INTRA | Estudios |
|---------------------|------------------|----------|
| Antraciclinas | Cada 2 ciclos (alto riesgo) | Eco-SLG, Troponina, NT-proBNP |
| Anti-HER2 | Cada 90 días | Eco-SLG, Troponina (alto riesgo) |
| VEGFi | Semanal SMBP + Eco c/120d | Home-BP, Eco 2D |
| BCR-ABL ITK | ECG c/90d, Eco c/180d | ECG, Eco 2D |
| ICI (inmunoterapia) | Cada ciclo (primeros 4) | Troponina, ECG |
| Inhibidor proteasoma | Cada 90 días | Eco 2D, SMBP |
| Fluoropirimidinas | Por síntomas | ECG |
| Deprivación androgénica | Cada 180 días | Lípidos, HbA1c |
| RT torácica | Reestratificación a 5 años | Eco-SLG, Consulta cardio |

**Fase basal (todos):** ECG + Eco-SLG + Troponina + NT-proBNP + Consulta cardiología (alto riesgo).

**Fase post:** 3 m + 12 m (alto riesgo) · anual (otros) · reestratificación 5 años (antraciclinas / RT).

**PROMs:** semanales durante todo el tratamiento (todas las clases).

---

## 9. Próximos pasos sugeridos

1. **Tests unitarios** del `scheduleEngine` con dataset de la Guía ESC 2022.
2. **Push web** (VAPID) para complementar el canal in-app.
3. **Internacionalización** del bot (es-AR / es-ES / pt-BR) para escalar a marca blanca regional.
4. **Integración con la Estratificación 2023** (Entregable 4): los flowcharts por droga refinan las reglas del engine.
5. **Dashboard de KPIs** (Entregable futuro): leer los recursos FHIR creados aquí para alimentar las métricas en vivo de la web preliminar.
