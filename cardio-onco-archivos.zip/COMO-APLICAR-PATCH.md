# Cómo aplicar el patch al repositorio

## 1. Pre-requisitos

- Tener clonado `https://github.com/EPA-Bienestar-com/programas`
- Estar en `master` actualizado: `git pull origin master`
- Trabajar en branch limpio (sin cambios sin commitear)

## 2. Aplicar el patch (3 comandos)

```bash
# Crear branch
git checkout -b feat/cardio-onco-scheduling

# Aplicar el patch (asegurate de que cardio-onco-scheduling.patch esté en el cwd)
git am cardio-onco-scheduling.patch

# Push y abrir PR
git push -u origin feat/cardio-onco-scheduling
```

GitHub te mostrará automáticamente el botón "Compare & pull request" al hacer push.

### Variantes alternativas

Si preferís no usar `git am` (que también ajusta autor + fecha), podés usar:

```bash
# Aplica solo los cambios de archivos sin crear commit
git apply cardio-onco-scheduling.patch
git add .
git commit -m "feat(cardio-onco): add scheduling and notifications module"
```

Para verificar antes de aplicar:

```bash
git apply --check cardio-onco-scheduling.patch    # verifica sin tocar nada
git apply --stat cardio-onco-scheduling.patch     # muestra estadísticas
```

## 3. Edición manual de `src/Router.tsx` (no incluida en el patch)

El patch crea **archivos nuevos**, pero modificar el `Router.tsx` existente requiere
una edición manual porque desconozco el contenido exacto actual del archivo en tu repo.

Abrí `src/Router.tsx` y agregá lo siguiente:

### A. En los imports (al inicio del archivo)

```tsx
import { lazy, Suspense } from 'react';

const SchedulePage = lazy(
  () => import('./pages/cardio-onco/scheduling/SchedulePage'),
);
const NotificationsPage = lazy(
  () => import('./pages/cardio-onco/notifications/NotificationsPage'),
);
```

### B. Dentro del `<Routes>` existente

Agregá estas dos rutas junto a las que ya existen:

```tsx
<Route
  path="/cardio-onco/schedule"
  element={
    <Suspense fallback={<div>Cargando…</div>}>
      <SchedulePage />
    </Suspense>
  }
/>
<Route
  path="/cardio-onco/notifications"
  element={
    <Suspense fallback={<div>Cargando…</div>}>
      <NotificationsPage />
    </Suspense>
  }
/>
```

### C. (Opcional) Gating por rol en el menú

En `src/components/Header.tsx` (o donde esté el menú de navegación), envolvé los
enlaces según el `resourceType` del profile:

```tsx
import { useMedplumProfile } from '@medplum/react';

const profile = useMedplumProfile();

{profile?.resourceType === 'Practitioner' && (
  <NavLink to="/cardio-onco/schedule">Cardio-Onco · Agenda</NavLink>
)}
{profile?.resourceType === 'Patient' && (
  <NavLink to="/cardio-onco/notifications">Mis recordatorios</NavLink>
)}
```

## 4. Despliegue del Bot de Medplum

El archivo `programas/cardio-onco/notification-bot.ts` es un **Bot server-side**,
no se incluye en el bundle del frontend. Para activarlo:

1. Ir al app de Medplum: `https://app.medplum.com/Bot/new`
2. Crear un nuevo Bot llamado `cardio-onco-notifications`
3. Copiar el contenido de `programas/cardio-onco/notification-bot.ts` en el editor del Bot
4. Crear una **Subscription** tipo cron con criteria `Communication?status=preparation`
   o configurar un Schedule recurrente diario (`0 9 * * *` ART)
5. Asignar permisos: `Project Admin → Bots → Run`

Documentación oficial: https://www.medplum.com/docs/bots/bot-basics

## 5. Verificación local antes del push

```bash
npm install      # solo si hay deps nuevas (no las hay en este patch)
npm run lint     # ESLint pasa sin warnings sobre los archivos nuevos
npm run build    # tsc + vite build no debe fallar
npm test         # vitest, si tenés tests del engine

# Smoke test manual
npm run dev
# Abrir http://localhost:3000/cardio-onco/schedule  (rol Practitioner)
# Abrir http://localhost:3000/cardio-onco/notifications  (rol Patient)
```

## 6. Sugerencia de descripción del PR

```
## feat(cardio-onco): scheduling engine + patient notifications

Implementa el módulo de calendarización y notificaciones cardio-oncológicas
basado en la Guía ESC 2022, sin alterar la arquitectura existente.

### Cambios

- **Motor de cronograma** (`src/lib/cardio-onco/scheduleEngine.ts`):
  reglas de seguimiento por clase farmacológica (antraciclinas, anti-HER2,
  VEGFi, BCR-ABL ITK, ICI, proteasoma, fluoropirimidinas, ADT, RT torácica)
  y nivel de riesgo HFA-ICOS.
- **Builders FHIR R4** (`src/lib/cardio-onco/fhir.ts`):
  CarePlan, Appointment, ServiceRequest, Task, Communication con
  codificación LOINC + SNOMED CT.
- **Vista cardiólogo** (`src/pages/cardio-onco/scheduling/SchedulePage.tsx`):
  configuración del régimen y aprobación del plan.
- **Vista paciente** (`src/pages/cardio-onco/notifications/NotificationsPage.tsx`):
  recordatorios agrupados por estado (vencidas / pendientes / atendidas).
- **Bot de Medplum** (`programas/cardio-onco/notification-bot.ts`):
  cron diario que despacha Communication a in-app/email/sms con
  trazabilidad vía AuditEvent.

### No incluye

- Edición de `src/Router.tsx` (ver instrucciones en el READMe del entregable).
- Tests unitarios del engine — agregar en PR siguiente.
- Despliegue del Bot — hacerlo desde el app de Medplum.

### Referencias

- ESC Guidelines on cardio-oncology, Eur Heart J 2022;43:4229-4361
- Medplum bots: https://www.medplum.com/docs/bots/bot-basics
```
