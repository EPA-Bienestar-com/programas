/**
 * notification-bot.ts — Medplum Bot
 *
 * Bot que se ejecuta de forma programada (cron diario) y dispara las
 * notificaciones cardio-oncológicas que corresponden a la fecha actual.
 *
 * Despliegue: este archivo se publica como un Bot en Medplum siguiendo
 * https://www.medplum.com/docs/bots/bot-basics. Una vez creado, se
 * vincula a una Subscription (cron) o se invoca vía un Schedule.
 *
 * Lógica:
 *  1. Busca recursos Communication en estado 'preparation' cuya fecha
 *     'sent' caiga en las próximas 24 h.
 *  2. Por cada uno, despacha al canal correspondiente:
 *      - in-app  → cambia status a 'in-progress' (visible en NotificationsPage)
 *      - email   → llama a sendEmail()
 *      - sms     → integra con proveedor SMS (Twilio, etc.)
 *      - push    → llama al servicio de push web
 *  3. Marca el Communication como 'in-progress' (despachada) y registra
 *     el evento en un AuditEvent.
 *
 * Variables de entorno esperadas en el Bot:
 *  - SMTP_RELAY_URL          (para email)
 *  - PUSH_WEB_VAPID_KEY      (para web push)
 */

import { BotEvent, MedplumClient } from '@medplum/core';
import type { AuditEvent, Communication, Patient } from '@medplum/fhirtypes';

interface BotInput {
  /** Si se especifica, solo procesa notificaciones de este paciente */
  patientId?: string;
  /** Modo dry-run: registra pero no despacha */
  dryRun?: boolean;
}

export async function handler(medplum: MedplumClient, event: BotEvent<BotInput>): Promise<unknown> {
  const input = event.input ?? {};
  const now = new Date();
  const horizon = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  // 1. Buscar notificaciones preparadas dentro de las próximas 24 h
  const search: Record<string, string> = {
    status: 'preparation',
    sent: `ge${now.toISOString()}`,
    _count: '500',
  };
  if (input.patientId) {
    search.recipient = `Patient/${input.patientId}`;
  }
  const due = await medplum.searchResources('Communication', search);

  const inWindow = due.filter((c) => {
    if (!c.sent) return false;
    const sent = new Date(c.sent).getTime();
    return sent <= horizon.getTime();
  });

  console.log(`[notification-bot] ${inWindow.length} notificaciones a despachar`);

  let dispatched = 0;
  for (const comm of inWindow) {
    try {
      await dispatchOne(medplum, comm, input.dryRun ?? false);
      dispatched++;
    } catch (err) {
      console.error(`[notification-bot] Error en Communication/${comm.id}:`, err);
      await audit(medplum, comm, 'failure', String(err));
    }
  }

  return {
    processed: inWindow.length,
    dispatched,
    skipped: inWindow.length - dispatched,
    dryRun: input.dryRun ?? false,
    timestamp: now.toISOString(),
  };
}

/* ============================================================
 * Despacho por canal
 * ============================================================ */

async function dispatchOne(
  medplum: MedplumClient,
  comm: Communication,
  dryRun: boolean,
): Promise<void> {
  const channel = comm.medium?.[0]?.coding?.[0]?.code ?? 'ELECTRONIC';
  const recipientRef = comm.recipient?.[0]?.reference;
  if (!recipientRef) {
    throw new Error('Communication sin recipient');
  }
  const patient = await medplum.readReference<Patient>({ reference: recipientRef });
  const subject = comm.topic?.text ?? 'Recordatorio';
  const body = comm.payload?.[0]?.contentString ?? '';

  if (dryRun) {
    console.log(`[dry-run] ${channel} → Patient/${patient.id}: ${subject}`);
    return;
  }

  switch (channel) {
    case 'EMAILWRIT':
      await sendEmail(patient, subject, body);
      break;
    case 'SMSWRIT':
      await sendSms(patient, body);
      break;
    case 'ELECTRONIC':
    default:
      // In-app: solo se actualiza el estado para que aparezca en
      // NotificationsPage del frontal.
      break;
  }

  await medplum.updateResource({
    ...comm,
    status: 'in-progress',
    sent: new Date().toISOString(),
  });
  await audit(medplum, comm, 'success');
}

/* ============================================================
 * Integraciones de canal — stubs, completar en producción
 * ============================================================ */

async function sendEmail(patient: Patient, subject: string, body: string): Promise<void> {
  const email = patient.telecom?.find((t) => t.system === 'email')?.value;
  if (!email) {
    throw new Error('Paciente sin email registrado');
  }
  // TODO: integrar SMTP/SES/SendGrid en producción.
  console.log(`[email] → ${email}: ${subject}`);
}

async function sendSms(patient: Patient, body: string): Promise<void> {
  const phone = patient.telecom?.find((t) => t.system === 'phone')?.value;
  if (!phone) {
    throw new Error('Paciente sin teléfono registrado');
  }
  // TODO: integrar Twilio/AWS SNS en producción.
  console.log(`[sms] → ${phone}: ${body.slice(0, 60)}…`);
}

/* ============================================================
 * AuditEvent — trazabilidad regulatoria
 * ============================================================ */

async function audit(
  medplum: MedplumClient,
  comm: Communication,
  outcome: 'success' | 'failure',
  detail?: string,
): Promise<void> {
  const ev: AuditEvent = {
    resourceType: 'AuditEvent',
    type: { system: 'http://terminology.hl7.org/CodeSystem/audit-event-type', code: 'rest', display: 'RESTful Operation' },
    subtype: [{ system: 'http://hl7.org/fhir/restful-interaction', code: 'update', display: 'update' }],
    action: 'U',
    recorded: new Date().toISOString(),
    outcome: outcome === 'success' ? '0' : '8',
    outcomeDesc: detail,
    source: { observer: { display: 'cardio-onco notification bot' } },
    entity: comm.id
      ? [{ what: { reference: `Communication/${comm.id}` }, role: { code: '4', display: 'Domain' } }]
      : undefined,
  };
  await medplum.createResource(ev);
}
